'''
Initial abandoned attempt at adding milestones.
'''
import re
import os
from fuzzywuzzy import fuzz
from fuzzywuzzy import process

voldoc = None

def read_in_ocr(inpath):
    """
    Takes a volume ocr doc from Zach and reads it into a dictionary keyed by pgnum strings "0001" etc. with values
    of a list of lines. To reference a page you need a zero-filled string of the page num. This gives you a list of
    lines where pagevar[0] is the first line pagevar[1] is the second, etc.

    :param inpath:
    :return:
    """
    global voldoc
    voldoc = []
    pgnm = '0'
    lnnm = 0
    with open(inpath, 'r') as fin:
        for ln in fin:
            ln = ln.strip()
            if '.tif' in ln:
                mtch = re.search(r'kama-vol-\d+/out__(\d+)', ln)
                if mtch:
                    pgnm = mtch.group(1)
                    lnnm = 0
                    continue
            elif ln == '':
                continue
            lnnm += 1
            ln = ln.replace('༄༅། ', '')
            voldoc.append(pgnm, str(lnnm), ln)


def read_in_chunk(cpath):
    intxt = ''
    with open(cpath, 'r') as fin:
        for ln in fin:
            ln = ln.strip()
            intxt += ln
    return intxt


def find_pages(unidocin, last_index, pagedref, firstpg):
    pagepos = {}
    numpgs = len(pagedref.keys())
    endpg = firstpg + numpgs - 1
    for n in range(firstpg, endpg + 1):
        pgkey = str(n).zfill(4)
        if pgkey not in pagedref:
            continue
        pglines = pagedref[pgkey]
        for x, ln in enumerate(pglines):
            # print("doing {}.{}".format(n, x + 1))
            tmpln = ln.lstrip('༄༅། ')
            foundpos = unidocin.find(tmpln, last_index)
            while foundpos == -1:
                tmpln = tmpln.split('་')
                tmpln.pop()
                if len(tmpln) == 1:
                    foundpos = unidocin.find(tmpln[0], last_index)
                    break

                tmpln = '་'.join(tmpln)
                foundpos = unidocin.find(tmpln, last_index)

            if foundpos > -1:
                print("Found with {} characters".format(len(tmpln)))
                linekey = "{}.{}".format(n, x + 1)
                pagepos[foundpos] = linekey
                last_index += len(ln)

        if n > 50:
            break

    poses = list(pagepos.keys())
    poses.sort(reverse=True)
    for ps in poses:
        ms = '{}'.format(pagepos[ps])
        pms = '[{}]'.format(ms.replace('.1', '')) if '.1' in ms else ''
        ms = pms + '[{}]'.format(ms)
        print(ms)
        unidocin = unidocin[:ps] + ms + unidocin[ps:]
    return last_index, unidocin


if __name__ == '__main__':

    # print(os.getcwd())
    # ld = os.listdir('.')
    # for f in ld:
    #     print("{}".format(f))

    ocrpath = 'kama-ocr-v2-in.txt'
    fpg, ocrdoc = read_in_ocr(ocrpath)
    unipath = 'KAMA-002-a.txt'
    unichunk = read_in_chunk(unipath)
    lastind = 0
    lastind, outdoc = find_pages(unichunk, lastind, ocrdoc, fpg)
    outpath = 'kama-0002-a-ms.txt'
    with open(outpath, 'w') as outf:
        outf.write(outdoc)

    print("Done")


