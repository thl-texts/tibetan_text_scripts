# Insert Milestones

This was the initial repository for the scripts to take a Sambhota file and insert milestone markers at the 
proper locations based on an OCRed version of the volume. Because it needs to work with other scripts in the 
Sambhota conversion repo, the relevant scripts from this repo have been moved there and that repo has been
renamed as "Tibetan Text Scripts". See https://github.com/thl-texts/tibetan_text_scripts.git 

*ALL SCRIPTS IN THIS REPO ARE OUTDATED!*
Delete when no longer needed for reference.

Scripts to insert milestones into Unicode Tibetan texts based on OCR output.
Originally written to insert milestones in Unicode texts converted from Sambhota Word files using the OCRed version 
of the same volumes. The OCR contains headers for new pages and each line is delineated by a paragraph return. 
The script uses fuzzyseach matching along with average line length to find the place in the Unicode files to put each 
milestone. 

The main script to do this is `breaksearch.py`
